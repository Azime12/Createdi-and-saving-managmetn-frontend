"use client"; 

import RegisterForm from "@/app/components/RegisterForm"; 

export default function RegisterPage() {
  return (
    <div className=" bg-gray-100">
      <RegisterForm />
    </div>
  );
}
