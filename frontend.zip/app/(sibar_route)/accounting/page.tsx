import SavingsManagement from '@/app/ui/saving/SavingsManagement'
import React from 'react'

function page() {
  return (
    <div>
      <SavingsManagement/>
    </div>
  )
}

export default page