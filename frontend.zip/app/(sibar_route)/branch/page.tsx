
import BranchManagement from '@/app/ui/branches/manageBranch'
 


export default function AdminPage() {
  return (
      


            <BranchManagement />

  );
}
