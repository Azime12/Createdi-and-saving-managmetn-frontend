import LoanManagementDashboard from '@/app/ui/loan/LoanManagementDashboard';


const LoanManagement = () => {
  





  

  return (
   <>
   <LoanManagementDashboard/>
   </>
  );
};

export default LoanManagement;