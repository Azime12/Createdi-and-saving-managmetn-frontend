import React from 'react'
import SettingsUi from '@/app/ui/settings/SettingMain';

function page() {
  return (
    <div>
      <SettingsUi/>
    </div>
  )
}

export default page