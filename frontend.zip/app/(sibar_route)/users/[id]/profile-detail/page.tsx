import React from 'react'
import  UserProfileDashboard from '@/app/ui/users/profileDetail/profileDetail'

function page() {
  return (
    <UserProfileDashboard/>
  )
}

export default page