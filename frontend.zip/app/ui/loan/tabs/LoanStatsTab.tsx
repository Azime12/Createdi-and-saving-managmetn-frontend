import React from 'react'

function LoanStatsTab() {
  return (
    <div>LoanStatsTab</div>
  )
}

export default LoanStatsTab