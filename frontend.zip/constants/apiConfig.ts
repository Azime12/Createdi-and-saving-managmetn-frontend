export const BASE_URL = "http://localhost:5000/api"; // Replace with your API URL

export const API_TAGS = {
  GROUP: 'Group',
  USER: 'User',
  AUTH:'Auth',
  Branch:'Branch',
  ROLELIST:'RoleList',
  PERMISSION:'Permission',
  USERPROFILE:'UserProfile',
  SAVING:'Saving',
  LOANTYPE:'LoanType',
  ROLE:"Role",
 LOANAPPLICATION :"LoanApplication",
 LOAN:"Loan",
 LOANPAYMENT:"LoanPayment",
  };
